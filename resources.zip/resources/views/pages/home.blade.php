@extends('layouts.app')

@section('title', 'Mapa de Sobral')

@section('content')
    <div id="map"></div>
@endsection
