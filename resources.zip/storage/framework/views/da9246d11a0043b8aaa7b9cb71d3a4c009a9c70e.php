<div class="topbar justify-content-between align-items-center bg-dark text-white">
    <div class="topbar-left">
        <img src="<?php echo e(asset('img/Logo_Sobral.png')); ?>" alt="Prefeitura de Sobral" class="logo">
    </div>
    <div class="topbar-center">
        <h1>Sobral em Mapas</h1>
    </div>
    <div class="topbar-right">
        <a href="#tutorial" class="btn btn-link text-white">Tutorial</a>
        <a href="#contato" class="btn btn-link text-white">Contato</a>
        <a href="#sobre" class="btn btn-link text-white">Sobre</a>
        <a href="#login" class="btn btn-link text-white">Login</a>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\sobralmapas2\resources\views\partials\topbar.blade.php ENDPATH**/ ?>