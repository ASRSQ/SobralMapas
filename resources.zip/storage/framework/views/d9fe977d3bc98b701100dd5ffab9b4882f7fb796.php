

<?php $__env->startSection('title', 'Mapa de Sobral'); ?>

<?php $__env->startSection('content'); ?>
    <div id="map"></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sobralmapas2\resources\views\pages\home.blade.php ENDPATH**/ ?>