<aside class="control-sidebar control-sidebar-<?php echo e(config('adminlte.right_sidebar_theme')); ?>">
    <?php echo $__env->yieldContent('right-sidebar'); ?>
</aside>
<?php /**PATH C:\xampp\htdocs\sobralmapas2\vendor\jeroennoten\laravel-adminlte\resources\views\partials\sidebar\right-sidebar.blade.php ENDPATH**/ ?>